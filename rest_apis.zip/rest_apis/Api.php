<?php

    require_once 'db.php';

    class Api {

        private $db;
        private $record;

        public function __construct() {
            $this->db = (new Database())->getConnection();
        }

        public function getProducts() {

            $query = "SELECT * FROM tbl_product";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $product = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($product);

        }

        public function geCategory() {

            $query = "SELECT * FROM tbl_category";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $category = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode($category);
        }

        public function getProductById($productId) {
           
            $query = "SELECT * FROM tbl_product WHERE product_id = :product_id";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':product_id', $productId);
            $stmt->execute();
    
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        
    }

    


?>