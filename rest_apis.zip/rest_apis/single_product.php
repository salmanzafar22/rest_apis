<?php 
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");


if (!isset($_GET['product_id']) || empty($_GET['product_id'])) {
    // Handle missing product ID error
    echo json_encode(['error' => 'Product ID is missing']);
    return;
}

$productId = filter_var($_GET['product_id'], FILTER_SANITIZE_NUMBER_INT);


require_once 'Api.php';
$apiController = new Api();
$product = $apiController->getProductById($productId);

// Check if the product was found
if (!$product) {
    // Handle product not found error
    echo json_encode(['error' => 'Product not found']);
    return;
}

// If the product is found, you can return it as JSON or in any desired format
echo json_encode($product);


?>